import bpy
import os
from bpy_extras.io_utils import ImportHelper
from bpy.types import PropertyGroup, CollectionProperty, AddonPreferences
from bpy.props import StringProperty, BoolProperty
from bpy.app.handlers import persistent

bl_info = {
    "name" : "BatchChanger",
    "author" : "Rivin",
    "description" : "",
    "blender" : (2, 83, 3),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "",
    "category" : "Generic"
}

classes = []


class BC_OT_Import(bpy.types.Operator, ImportHelper):
    bl_idname = "bc.import"
    bl_label = "Batch Import"
    bl_options = {'REGISTER'}

    filename_ext = ".blend"
    filter_glob: StringProperty( default='*.blend', options={'HIDDEN'} )
    files : bpy.props.CollectionProperty(type= PropertyGroup)

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences
        fp = os.path.dirname(self.filepath)
        l = []
        for f in self.files:
            l.append(os.path.join(fp, f.name))
        prefs.filepaths = "///".join(l[:])
        return {"FINISHED"}
classes.append(BC_OT_Import)

class BC_OT_Start(bpy.types.Operator):
    bl_idname = "bc.start"
    bl_label = "Batch Start"
    bl_options = {"REGISTER"}

    def execute(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences
        if len(prefs.filepaths):
            prefs.start = True
            bpy.ops.wm.open_mainfile(filepath= GetFirstPath())
        else:
            self.report({'ERROR'}, "You need to select the Batchfiles first")
        return {"FINISHED"}

    def draw(self, context):
        prefs = bpy.context.preferences.addons[__name__].preferences
        layout = self.layout
        layout.label(text= "All .blend Files")
        box = layout.box()
        for i in prefs.filepaths.split("///"):
            box.label(text= os.path.basename(i))
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
classes.append(BC_OT_Start)

@persistent
def startbatch(dummy):
    prefs = bpy.context.preferences.addons[__name__].preferences
    if prefs.start:
        print(prefs.filepaths)
        print("Current Filepath: " + bpy.data.filepath)
        bpy.ops.file.make_paths_relative()
        bpy.ops.wm.save_mainfile()
        if prefs.filepaths == '':
            prefs.start = False
            return
        bpy.ops.wm.open_mainfile(filepath= GetFirstPath())

def GetFirstPath():
    prefs = bpy.context.preferences.addons[__name__].preferences
    split = prefs.filepaths.split("///")
    prefs.filepaths = "///".join(split[1:])
    return split[0]

class BC_Prefs(AddonPreferences):
    bl_idname = __name__

    filepaths : StringProperty(name= "paths")
    start : BoolProperty(name= "STart")
classes.append(BC_Prefs)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.app.handlers.load_post.append(startbatch)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    bpy.app.handlers.load_post.remove(startbatch)

