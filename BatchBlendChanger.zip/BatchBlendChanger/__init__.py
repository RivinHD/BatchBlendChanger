import bpy
import os
from bpy_extras.io_utils import ImportHelper
from bpy.types import PropertyGroup, CollectionProperty, AddonPreferences
from bpy.props import StringProperty, BoolProperty
from bpy.app.handlers import persistent

bl_info = {
    "name" : "BatchChanger",
    "author" : "Rivin",
    "description" : "",
    "blender" : (2, 83, 3),
    "version" : (1, 0, 0),
    "location" : "",
    "warning" : "",
    "category" : "Generic"
}

classes = []

class BC_OT_Import(bpy.types.Operator, ImportHelper):
    bl_idname = "bc.import"
    bl_label = "Batch Import"
    bl_options = {'REGISTER'}

    filename_ext = ".blend"
    filter_glob: StringProperty( default='*.blend', options={'HIDDEN'} )
    files : bpy.props.CollectionProperty(type= PropertyGroup)

    def execute(self, context):
        fp = os.path.dirname(self.filepath)
        l = []
        for f in self.files:
            l.append(os.path.join(fp, f.name))
        with open(os.path.join(os.path.dirname(__file__), "Batchpaths.txt"), "w", encoding='utf8') as txtpath:
            txtpath.write("///".join(l[:]))
        return {"FINISHED"}
classes.append(BC_OT_Import)

class BC_OT_Start(bpy.types.Operator):
    bl_idname = "bc.start"
    bl_label = "Batch Start"
    bl_options = {"REGISTER"}

    def execute(self, context):
        with open(os.path.join(os.path.dirname(__file__), "Batchpaths.txt"), "r", encoding='utf8') as txtpath:
            txt = txtpath.read()
            if txt != '':
                with open(os.path.join(os.path.dirname(__file__), "Batchstart.txt"), "w", encoding='utf8') as txtpath:
                    txtpath.write("True")
                bpy.ops.wm.open_mainfile(filepath= GetFirstPath())
            else:
                self.report({'ERROR'}, "You need to select the Batchfiles first")
        return {"FINISHED"}

    def draw(self, context):
        layout = self.layout
        layout.label(text= "All .blend Files")
        box = layout.box()
        with open(os.path.join(os.path.dirname(__file__), "Batchpaths.txt"), "r", encoding='utf8') as txtpath:
            txt = txtpath.read()
            for i in txt.split("///"):
                box.label(text= os.path.basename(i))
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
classes.append(BC_OT_Start)

@persistent
def startbatch(dummy):
    with open(os.path.join(os.path.dirname(__file__), "Batchstart.txt"), "r", encoding='utf8') as txtpath:
        start = txtpath.read()
        if start == "True":
            with open(os.path.join(os.path.dirname(__file__), "Batchpaths.txt"), "r", encoding='utf8') as txtpath:
                txt = txtpath.read()
                print("------------------------------------------------------------------------")
                print("Current Filepath: " + bpy.data.filepath)
                bpy.ops.file.make_paths_relative()
                bpy.ops.wm.save_mainfile()
                if txt == '':
                    with open(os.path.join(os.path.dirname(__file__), "Batchstart.txt"), "w", encoding='utf8') as txtpath:
                        txtpath.write("False")
                    return
                bpy.ops.wm.open_mainfile(filepath= GetFirstPath())

def GetFirstPath():
    txt = ""
    with open(os.path.join(os.path.dirname(__file__), "Batchpaths.txt"), "r", encoding='utf8') as txtpath:
        txt = txtpath.read()
    split = txt.split("///")
    txt = "///".join(split[1:])
    with open(os.path.join(os.path.dirname(__file__), "Batchpaths.txt"), "w", encoding='utf8') as txtpath:
        txtpath.write(txt)
    return split[0]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.app.handlers.load_post.append(startbatch)

def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
    bpy.app.handlers.load_post.remove(startbatch)

